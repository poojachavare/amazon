package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.When;

public class phonepaystep {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		@When("Enter the username")
//		public void enter_the_username() {
//			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Pooja\\Downloads\\chromedriver_win32 (7)\\chromedriver.exe");
//			driver=new ChromeDriver();
//			
//			driver.manage().window().maximize();
//			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
//		
//		}
//
//		@When("Enter the password")
//		public void enter_the_password() {
//		    // Write code here that turns the phrase above into concrete actions
//		    throw new io.cucumber.java.PendingException();
//		}
//
//		@When("Click on login button")
//		public void click_on_login_button() {
//		   
//		}
//
//	}

}
